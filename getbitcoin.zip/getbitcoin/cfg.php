<?php

//BAHAN YANG PERLU DIINSTAL DI TERMUX
//[1]. pkg install php
//[2]. pkg install tesseract
//[3]. pkg install imagemagick
//Sampai Sini sudah Paham Kan 
//Jangan Lupa Subscribe Chanel Penghasil Gratisa


$ua = "xxxxxxxx";

$PHPSESSID = "xxxxxxxx";

$get_id = "xxxxxx";